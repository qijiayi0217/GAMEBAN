<!DOCTYPE html><!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">         
	<title>GameBan: Home</title>
        <link rel="stylesheet" href="sss/sss.css">
        <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<!--Query-->
<?php
require_once('db_setup.php');
$sql = "USE jzh136;";
if ($conn->query($sql) === FALSE) {echo "Error using  database: " . $conn->error;}
//QUERY
$sql = "SELECT * FROM games";
$result = $conn->query($sql);
if($result->num_rows > 0){
?>

<div class="container">
	<header class="banner">
		<h1><a href="index.php">GameBan</a></h1>
        </header>
       
	 <nav class="menu">
                <ul>
                <li><a class="current" href="index.html">Home</a></li>
		<li><a href="upload.html">Post a New Game</a></li>
                <li><a href="account.php">My Account</a></li>
                </ul>
         </nav>
         <br></br>
<!--Search Form-->
<div>
	<form action="find_game.php" method="post">
	Search a game you know: <input type="text" name="id"><br>
	<input type="submit">
</div>

         <div class="sp-container">
<!--Display all games-->
<?php
while($row = $result->fetch_assoc()){
?>

	<div class="game">
	<h2><?php echo $row['gameName']?></h2>
	<figure><img src="images/<?php echo $row['gameName']?>.jpg"></figure>
	<p>Category:  <?php echo $row['category']?></p>
	<p><?php echo $row['description']?></p>
	</div>
<?php
}
}
else {
echo "Nothing to display";
}
?>

	</div>
	<br><br>
</div>

<?php
$conn->close();
?>  

</body>
</html>
