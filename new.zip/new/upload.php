<!DOCTYPE html>
<html>
<head>

</head>

<body>
<?php
require_once('db_setup.php');
$sql = "USE jzh136;";
if ($conn->query($sql) === TRUE) {
   // echo "connected successfully";
} else {
   echo "Error using  database: " . $conn->error;
}

//Insert:
$gameName = $_POST['gameName'];
$category = $_POST['category'];
$description = $_POST['description'];
$sql = "INSERT INTO games values ('$gameName', '$category', '$description');";


$result = $conn->query($sql);

if ($result === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>


<?php

  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
    echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    echo "Type: " . $_FILES["file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

    //if (file_exists("upload/" . $_FILES["file"]["name"]))
    // {
    //  echo $_FILES["file"]["name"] . " already exists. ";
    //  }
    //else
    //  {
    // to save the image in the name of the game   
      $fileName=$_FIFLES['file']['name'];
      $name=explode('.',$fileName);
      $newPath=$gameName.'.'.$name[1];
      move_uploaded_file($_FILES["file"]["tmp_name"], "image/" . $newPath);
      
      
    //  echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
    //  }
    }

?>
    
<?php
$conn->close();
?>

</body>

</html>
