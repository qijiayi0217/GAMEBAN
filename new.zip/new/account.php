<!doctype html> 
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="utf-8">
		<title>GameBan: Account Info</title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
    <body>
    	<div class="container">
	    	<header class="banner">
				<h1><a href="index.php">GameBan</a></h1>
			</header>
			<nav class="menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="upload.html">Post a New Game</a></li>
					<li><a class="current" href="account.php">My Account</a></li>
				</ul>
			</nav>
<?php
require_once('db_setup.php');
$sql = "USE jzh136;";
if ($conn->query($sql) === TRUE) {
   // echo "successful"
} else {
   echo "Error using  database: " . $conn->error;
}

// Query:
$userName ='Jing' ;
$sql = "SELECT * FROM 410users  where UserName = '$userName';";


$result = $conn->query($sql);

if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
?>

			<div class="accInfo">
				<br></br>
				<p> Username:<?php echo $row['UserName']?> </p>
				<p> Password:<?php echo $row['Password']?> </p>
				<p> Age:<?php echo $row[age]?> </p>
				<p> Gender:<?php echo $row['gender']?> </p>
				<br></br>
			</div>
	        	        
		</div> <!--.container-->
<?php
}
}
else {
echo "Item not found";
}


$conn->close();
?>

    </body>
</html>
