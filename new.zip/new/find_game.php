<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/gamePage.css">
<!--Ajax-->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$(function(){
        var comments = $("#comments");
        $.getJSON("server.php",function(json){
                $.each(json,function(index,array){
                        var txt = "<p><strong>"+array["user"]+"</strong>："+array["comment"]+"<span>"+array["addtime"]+"</span></p>";
                        comments.append(txt);
                });
        });
        $("#add").click(function(){
           //     var user = $("#user").val();
                var txt = $("#txt").val();
        	var game = $("#gameName").text();
	$.ajax({
             type: "POST",
             url: "comment.php",
             data: "txt="+txt+"&gameName="+game,
             success: function(msg){
                                if(msg==1){
                                   var str = "<p><strong>"+user+"</strong>："+txt+"<span>Just now</span></p>";
                       comments.append(str);
                                   $("#message").show().html("Success！").fadeOut(1000);
                                   $("#txt").attr("value","");
                                }else{
                                   $("#message").show().html(msg).fadeOut(1000);
                            }
             }
            });
        });
});
</script>


</head>
<body>

<?php
require_once('db_setup.php');
$sql = "USE jzh136;";
if ($conn->query($sql) === FALSE) {echo "Error using  database: " . $conn->error;}
// Query:
$id = $_POST['id'];
$sql = "SELECT * FROM games where gameName like '%$id%';";
$result = $conn->query($sql);
if($result->num_rows > 0){
?>
<?php
while($row = $result->fetch_assoc()){
?>
	<h1 id='gameName'><?php echo $row['gameName']?></h1>
  	<h3><?php echo $row['category']?></h3>
  	<figure>
    	<img src="images/<?php echo $row['gameName']?>.jpg">
  	</figure>
	<h4><?php echo $row['description']?></h4>
<?php
}
}
else {
echo "Item not found";
}
?>

<!--Ajax Comment Function-->
<br></br>
<br></br>

<div id="main">
<div class="demo">
  <div id="comments">
     <h3>The comments</h3>
     <p><strong>Username</strong>：comment<span>2011-01-09 21:06:12</span></p>
  </div>
  <div id="post">
     <h3>POST A NEW COMMENT</h3>
    <!-- <p>USERNAME：</p>-->
    <!-- <p><input type="text" class="input" id="user" /></p>-->
     <p>COMMENT：</p>
     <p><textarea class="input" id="txt" style="width:100%; height:80px"></textarea></p>
     <p><input type="submit" value="Submit" id="add" /></p>
     <div id="message"></div>
  </div>
</div>
</div>

<?php
$conn->close();
?>  

</body>
</html>
